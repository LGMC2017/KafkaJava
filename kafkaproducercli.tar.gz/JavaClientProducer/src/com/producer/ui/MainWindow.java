package com.producer.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MainWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private static final int WWIDHT = 550;
	private static final int WHEIHGT = 420;
	private static final Dimension WINDIM = new Dimension(WWIDHT / 2, WHEIHGT / 2);
	
	private JPanel[] panels;
	private JButton btnSend = new JButton("Send");
	private JTextField txtSend = new JTextField(15);
	
	public MainWindow() {
		super();
		setSize(WINDIM);
		setTitle("Kafka Sender");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		initComponents();
	}
	
	private void initComponents() {
		panels = new JPanel[2];
		panels[0] = new JPanel();
		panels[1] = new JPanel();
		
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(panels[0], BorderLayout.NORTH);
		this.getContentPane().add(panels[1], BorderLayout.CENTER);
		
		panels[0].add(txtSend);
		panels[1].add(btnSend);
		
		btnSend.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				String message = txtSend.getText();
				
				if(!message.isEmpty()) {
					System.out.println("Sending: " + message);					
				}
			}
		});
	}

}
