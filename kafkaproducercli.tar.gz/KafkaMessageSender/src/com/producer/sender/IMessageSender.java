package com.producer.sender;

import java.io.IOException;

public interface IMessageSender {
	
	public void sendMessage(String s);
	public void sendFile(String filepath) throws IOException;

}
