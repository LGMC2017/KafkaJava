

import javax.swing.JDialog;
import javax.swing.JFrame;

import com.producer.ui.MainWindow;

public class MainProgram {

	public static void main(String[] args) {
		launchProgram();
	}

	private static void launchProgram() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		MainWindow mw = new MainWindow();
		mw.setVisible(true);
	}

}
