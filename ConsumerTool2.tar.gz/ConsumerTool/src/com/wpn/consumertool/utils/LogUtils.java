package com.wpn.consumertool.utils;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogUtils {
	
	private static Logger logger;
	
	public static void LogAt(Class<?> clss, Level level, String message) {

		logger = LogManager.getLogger(clss);
		logger.log(level,message);
	}
	public static void LogInfo(String message) {

		logger = LogManager.getLogger(LogUtils.class);
		logger.log(Level.WARN, message);
	}
	
	static {
		System.setProperty("log4j.configurationFile", "resources/log4j.xml");
	}

}
