package com.wpn.consumertool.utils;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtils {
	
	private static ObjectMapper objectMapper;
	
	public static String parseToJson(Object source) {		
		String json = "";
        try {
        	json = objectMapper.writeValueAsString(source);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
	}
	
	public static Map<String, Object> marshallFromJson(String jsonstring) throws JsonParseException, JsonMappingException, IOException {				
		Map<String, Object> jsonMap = objectMapper.readValue(jsonstring, new TypeReference<Map<String,Object>>(){});
		return jsonMap;
	}
	
	static {
		objectMapper = new ObjectMapper();		
	}
	
}
