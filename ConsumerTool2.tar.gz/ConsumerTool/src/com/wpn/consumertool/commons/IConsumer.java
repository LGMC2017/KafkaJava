package com.wpn.consumertool.commons;

import java.util.Observer;

public interface IConsumer<K, V> {
	/**
	 * 
	 */
	void init();

	/**
	 * 
	 */
	void close();

	/**
	 * 
	 */
	void getMessagesFrom(String topic);

	/**
	 * 
	 */
	void addObserver(Observer observer);
}
