package com.wpn.consumertool.dbengine;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class WPNConnectionEngine {
	
	public static void main(String[] args) {
		try {
			for(int i = 0; i < 1000; i++) {
				
				DataSource ds = DataSource.getInstance();
				Connection con = ds.getConnection();
				PreparedStatement stm = con.prepareStatement("SELECT * FROM \"public\".\"Users\"");
				ResultSet rs = stm.executeQuery();
				
				while(rs.next()) {
					int rid = rs.getInt("id");
					String rlogname = rs.getString("logname");
					System.out.println("id=" + rid + ", name=" + rlogname);
				}
				
				rs.close();
				stm.close();
				con.close();
				
				System.out.println("" + i);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
