package com.wpn.consumertool.observers;

import java.util.Observable;

public class MessageNotifier extends Observable {
	
	@Override
	public void notifyObservers(Object arg) {
		// TODO Auto-generated method stub
		super.setChanged();
		super.notifyObservers(arg);
	}
}
