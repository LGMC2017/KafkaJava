package com.wpn.consumertool.observers;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.consumer.OffsetCommitCallback;
import org.apache.kafka.common.TopicPartition;
import org.apache.logging.log4j.Level;

import com.wpn.consumertool.beans.KafkaConsumerInfo;
import com.wpn.consumertool.utils.JsonUtils;
import com.wpn.consumertool.utils.LogUtils;

public class GenericObserver implements Observer {
	
	Map<TopicPartition, OffsetAndMetadata> commitmap = new HashMap<TopicPartition, OffsetAndMetadata>();
	
	@Override
	public void update(Observable o, Object arg) {
		@SuppressWarnings("unchecked")
		final KafkaConsumerInfo<String, String> ci = (KafkaConsumerInfo<String, String>) arg;
		final ConsumerRecord<String, String> record = ci.getConsumerRecord();
		final KafkaConsumer<String, String> consumer = ci.getKafkaConsumer();
		try {
			Map<String, Object> retrievedobject = JsonUtils.marshallFromJson(record.value());
			//LogUtils.LogInfo(String.format("%s %s", "Message Marshalling Success!\n", retrievedobject.toString()));
			TopicPartition partition = new TopicPartition(record.topic(), record.partition());
			OffsetAndMetadata offset = new OffsetAndMetadata(record.offset() + 1, new String());
			commitmap.clear();
			commitmap.put(partition, offset);
			consumer.commitSync(commitmap);
			LogUtils.LogInfo(String.format("%s %s", retrievedobject.toString(), " was commited."));
			///doing async.
//			consumer.commitAsync(commitmap, new OffsetCommitCallback() {
//				@Override
//				public void onComplete(Map<TopicPartition, OffsetAndMetadata> offsets, Exception exception) {
//					LogUtils.LogInfo(String.format("%s %s", retrievedobject.toString(), " was commited."));
//				}
//			});
		}
		catch(IOException ex) {
			LogUtils.LogAt(GenericObserver.class, Level.ERROR, ex.getMessage());
		}
	}
	
}
