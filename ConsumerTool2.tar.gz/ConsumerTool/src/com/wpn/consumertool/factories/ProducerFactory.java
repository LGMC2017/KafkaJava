package com.wpn.consumertool.factories;

import java.util.Properties;

import com.wpn.consumertool.commons.IProducer;
import com.wpn.consumertool.implementation.WPNProducer;

public class ProducerFactory {
	
	private static Properties properties;
	
	private static void initDefaultConfig() {
		properties = new Properties();
		properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
		properties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.setProperty("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	}
	
	public static IProducer<String, String> buildProducer() {
		initDefaultConfig();
		return new WPNProducer<String, String>(properties);
	}

	@SuppressWarnings("unused")
	private static IProducer<String, String> buildProducer(Properties properties) {
		ProducerFactory.properties = properties;
		return new WPNProducer<String, String>(properties);
	}
	
}
