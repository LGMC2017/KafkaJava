package com.wpn.consumertool.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;
import org.apache.logging.log4j.Level;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wpn.consumertool.beans.DataClass;
import com.wpn.consumertool.commons.IConsumer;
import com.wpn.consumertool.commons.IProducer;
import com.wpn.consumertool.factories.ConsumerFactory;
import com.wpn.consumertool.factories.ProducerFactory;
import com.wpn.consumertool.utils.HelperUtils;
import com.wpn.consumertool.utils.JsonUtils;
import com.wpn.consumertool.utils.LogUtils;

public class ProgramMain {

	private static final String CONFIGFILE = "resources/log4j.xml";
	private static final String TOPICNAME = "test";
	private static final int THREADPOOL = 10;
	private static final int NUMTHREADS = 1;
	
	private static ExecutorService executor;
	private static List<Callable<Void>> tasks = new ArrayList<Callable<Void>>();

	public static void main(String[] args) {
		System.out.println("Running on Java " + HelperUtils.getJDKVersion());
		testConsumer();
		//testProducer();
	}

	@SuppressWarnings("unused")
	private static void justCode() throws IOException {
		Path path = Paths.get("data/data.json");
		String contentbody = new String(Files.readAllBytes(path));
		ObjectMapper objectMapper = new ObjectMapper();
		final ConcurrentHashMap<String, Object> jsonMap = objectMapper.readValue(contentbody, new TypeReference<Map<String, Object>>() {
		});
	}

	@SuppressWarnings("unused")
	private static void testProducer() {
		IProducer<String, String> producer = ProducerFactory.buildProducer();
		final DataClass dclass = new DataClass();
		for (int i = 0; i < 1000; i++) {
			dclass.setId(i + 1);
			String jsondata = JsonUtils.parseToJson(dclass);
			producer.sendMessageTo(ProgramMain.TOPICNAME, jsondata);
		}
		producer.close();
	}

	@SuppressWarnings("unused")
	private static void testConsumer() {

		//IConsumer<String, String> consumer = ConsumerFactory.buildConsumer(); //id need to use just one consumer for all threads, use this.

		//creates a runnable with callback
		final Runnable runnabletask = () -> {
			IConsumer<String, String> consumer = ConsumerFactory.buildConsumer(); //uses one consumer per thread.
			consumer.getMessagesFrom(ProgramMain.TOPICNAME);
			consumer.close();
			executor.shutdownNow();
		};
		//converts the runnable to tasks-collection
		for (int i = 1; i <= NUMTHREADS; i++) {
			final Callable<Void> task = () -> {
				runnabletask.run();
				return null;
			};
			tasks.add(task);
		}
		
		executor = Executors.newFixedThreadPool(THREADPOOL);

		try {
			//executes the task collection.
			executor.invokeAll(tasks);
		} catch (InterruptedException exc) {
			LogUtils.LogAt(ProgramMain.class, Level.ERROR, exc.getMessage());
		}
		
	}

	static {
		PropertyConfigurator.configure(CONFIGFILE);
		BasicConfigurator.configure();
	}
}
