package com.wpn.consumertool.beans;

public class DataClass {
	
	private boolean active;
	private int Id;
	private String name;
	
	public DataClass() {
		this.active = true;
		Id = 0;
		this.name = "NO_NAME";
	}
	
	public DataClass(boolean active, int id, String name) {
		this.active = active;
		Id = id;
		this.name = name;
	}
	
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
