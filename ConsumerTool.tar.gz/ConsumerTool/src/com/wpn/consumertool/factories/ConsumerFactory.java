package com.wpn.consumertool.factories;

import java.util.Properties;

import com.wpn.consumertool.commons.IConsumer;
import com.wpn.consumertool.implementation.WPNConsumer;

public class ConsumerFactory {

	private static Properties properties;

	private static void initDefaultConfig() {
		properties = new Properties();
		properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
		properties.setProperty("group.id", "test");
		properties.setProperty("enable.auto.commit", "false");
		properties.setProperty("auto.commit.interval.ms", "1000");
		properties.setProperty("session.timeout.ms", "30000");
		properties.setProperty("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		properties.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		properties.setProperty("auto.offset.reset","earliest");
	}

	public static IConsumer<String, String> buildConsumer() {
		initDefaultConfig();
		return new WPNConsumer<String, String>(properties);
	}
	
	public static IConsumer<String, String> buildConsumer(Properties _properties) {
		properties = _properties;
		return new WPNConsumer<String, String>(properties);
	}
}
