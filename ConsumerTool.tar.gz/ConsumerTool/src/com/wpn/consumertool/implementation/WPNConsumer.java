package com.wpn.consumertool.implementation;

import java.time.Duration;
import java.util.Arrays;
import java.util.Observable;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.logging.log4j.Level;

import com.wpn.consumertool.beans.KafkaConsumerInfo;
import com.wpn.consumertool.commons.IConsumer;
import com.wpn.consumertool.observers.MessageNotifier;
import com.wpn.consumertool.observers.TopicObserver;
import com.wpn.consumertool.utils.LogUtils;

public class WPNConsumer<K, V> implements IConsumer<K, V> {
	
	private Observable notifier;
	private KafkaConsumer<K, V> kconsumer;
	private boolean keepRunning = true;
	private boolean fetched = false;
	private int emptytimes = 0;
	
	private final int MAXEMPTYTIMES = 5;
	private final Duration DELAY = Duration.ofSeconds(1);
	
	public WPNConsumer(Properties _properties) {
		kconsumer = new KafkaConsumer<K, V>(_properties);
		notifier = new MessageNotifier();
		TopicObserver to = new TopicObserver();
		notifier.addObserver(to);
	}

	@Override
	public void init() {

	}

	@Override
	public void close() {
		kconsumer.close();
	}
	
    /* stops the running after MAXEMPTYTIMES without receiving records. */
	private void checkAvailability(boolean _fetchedflag) {
		if(! _fetchedflag) {
			emptytimes++;
			LogUtils.LogAt(WPNConsumer.class, Level.WARN, "\nINTERNAL: " + emptytimes + " times without fetching any message...");
			if(emptytimes >= MAXEMPTYTIMES) {
				LogUtils.LogAt(WPNConsumer.class, Level.WARN, "This consuming process will end.");
				keepRunning = false;
			}
		}
		else {
			emptytimes = 0;
		}
	}
	
	@Override
	public void getMessagesFrom(String topic) {
		kconsumer.subscribe(Arrays.asList(topic));
		while (keepRunning) {
	         fetched = false;
	         ConsumerRecords<K, V> records = kconsumer.poll(DELAY);
	         for (ConsumerRecord<K, V> record : records) {	        	
	        	 notifier.notifyObservers(new KafkaConsumerInfo<K, V>(kconsumer, record));
	         }
	         /* stops the running after MAXEMPTYTIMES without receiving records. */
	         checkAvailability(fetched);
	      }
	}
}
