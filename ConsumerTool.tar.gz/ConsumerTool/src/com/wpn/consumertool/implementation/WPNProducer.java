package com.wpn.consumertool.implementation;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.wpn.consumertool.commons.IProducer;

public class WPNProducer<K, V> implements IProducer<K, V> {
	private KafkaProducer<K, V> kproducer;
	
	public WPNProducer(Properties _properties) {
		kproducer = new KafkaProducer<K, V>(_properties);
	}

	@Override
	public void init() {

	}
	@Override
	public void close() {
		kproducer.close();
	}

	@Override
	public void sendMessageTo(K topic, V message) {
		kproducer.send(new ProducerRecord<K, V>((String) topic, message));
		kproducer.flush();
	}
	
}
