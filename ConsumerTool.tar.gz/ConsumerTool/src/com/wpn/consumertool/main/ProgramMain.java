package com.wpn.consumertool.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;
import org.apache.logging.log4j.Level;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wpn.consumertool.commons.IConsumer;
import com.wpn.consumertool.commons.IProducer;
import com.wpn.consumertool.factories.ConsumerFactory;
import com.wpn.consumertool.factories.ProducerFactory;
import com.wpn.consumertool.utils.HelperUtils;
import com.wpn.consumertool.utils.LogUtils;

public class ProgramMain {
	
	private static final String CONFIGFILE = "resources/log4j.xml";
	
	/**************************************************************/
	
	public static void main(String[] args) {
		System.out.println("Running on Java " + HelperUtils.getJDKVersion());
		LogUtils.LogAt(ProgramMain.class, Level.INFO, "Starting Program");
		//testProducer();
		testConsumer();
	}
	
	/**************************************************************/
	
	@SuppressWarnings("unused")
	private static void justCode() throws IOException {
		Path path = Paths.get("data/data.json");		
		String contentbody = new String(Files.readAllBytes(path));				
		ObjectMapper objectMapper = new ObjectMapper();		
		Map<String, Object> jsonMap = objectMapper.readValue(contentbody, new TypeReference<Map<String,Object>>(){});
	}
	
	@SuppressWarnings("unused")
	private static void testProducer() {
		IProducer<String, String> producer = ProducerFactory.buildProducer();
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.sendMessageTo("test", "Kafka Message");
		producer.close();		
	}
	
	@SuppressWarnings("unused")
	private static void testConsumer() {
		IConsumer<String, String> consumer = ConsumerFactory.buildConsumer();
		consumer.getMessagesFrom("test");
		consumer.close();
	}
	
	static {
		PropertyConfigurator.configure(CONFIGFILE);
		BasicConfigurator.configure();
	}
}
