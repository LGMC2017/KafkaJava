package com.wpn.consumertool.utils;

public class HelperUtils {
	
	public static final String ENV_VERSION = "java.specification.version";
	public static final String ENV_APPVERSION = "java.version";
	
	public static String getJDKVersion() {
		return System.getProperty(ENV_VERSION);
	}
	public static String getAppVersion() {
		return System.getProperty(ENV_APPVERSION);
	}

}
