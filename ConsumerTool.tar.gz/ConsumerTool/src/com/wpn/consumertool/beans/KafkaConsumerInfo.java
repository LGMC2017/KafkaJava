package com.wpn.consumertool.beans;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class KafkaConsumerInfo<K,V> {

	private KafkaConsumer<K,V> kafkaConsumer;
	private ConsumerRecord<K,V> consumerRecord;
	
	public KafkaConsumerInfo(KafkaConsumer<K,V> _kafkaConsumer,  ConsumerRecord<K,V> _consumerRecord) {
		this.kafkaConsumer = _kafkaConsumer;
		this.consumerRecord = _consumerRecord;
	}
	
	public KafkaConsumer<K, V> getKafkaConsumer() {
		return kafkaConsumer;
	}

	public void setKafkaConsumer(KafkaConsumer<K, V> kafkaConsumer) {
		this.kafkaConsumer = kafkaConsumer;
	}

	public ConsumerRecord<K, V> getConsumerRecord() {
		return consumerRecord;
	}

	public void setConsumerRecord(ConsumerRecord<K, V> consumerRecord) {
		this.consumerRecord = consumerRecord;
	}
	
	
}
