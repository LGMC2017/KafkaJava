package com.wpn.consumertool.commons;

public interface IProducer<K, V> {
	void init();	
	void sendMessageTo(K topic, V message);	
	void close();
}
