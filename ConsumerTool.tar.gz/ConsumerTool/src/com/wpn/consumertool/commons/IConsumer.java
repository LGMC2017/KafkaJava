package com.wpn.consumertool.commons;

public interface IConsumer<K, V> {
	void init();	
	void close();	
	void getMessagesFrom(String topic);
}
