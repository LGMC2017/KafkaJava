package com.wpn.consumertool.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class FileConfiguration {

	private static FileConfiguration config = null;
	private static Properties properties;

	public static FileConfiguration init(String fileconfig_path) throws IOException {
		if (config == null) {
			config = new FileConfiguration();
		}
		load(fileconfig_path);
		return config;
	}
	
	private static void load(String fileconfig_path) throws IOException {
		File configFile = new File(fileconfig_path);
		InputStream input = new FileInputStream(configFile);
		properties = new Properties();
		properties.load(input);
	}
	
	public static Properties getProperties() {
		return FileConfiguration.properties;
	}

	public static Object getProperty(String property) {
		return properties.get(property);
	}

	public static void addProperty(String key, Object value) {
		properties.put(key, value);

	}
}
